<?php
$host = "localhost";
	$user= "root";
	$password = "";
	$port = "3306";
	$database = "catchme";
	$conn = mysqli_connect($host, $user, $password, $database);
?>